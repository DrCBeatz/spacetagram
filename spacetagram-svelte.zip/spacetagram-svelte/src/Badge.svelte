<script>
  import { fade } from "svelte/transition";
</script>

<style>
  span {
    display: inline-block;
    margin: 0 0.25rem;
    border-radius: 3px;
    border: 1px solid #cf0056;
    background: #cf0056;
    color: white;
    padding: 0 0.5rem;
    font-family: "Lato", sans-serif;
    font-size: 0.8rem;
  }
  h3 { 
    color: white;
  }

  .center-div {
    text-align: center;
  }
</style>
<div class="center-div">
<span transition:fade>
  <h3><slot></slot></h3>
</span>
</div>